namespace ConversorMoedas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            var resposta = MessageBox.Show("Deseja encerrar o programa?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Error);

            if (resposta == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            txtValor.Clear();
            txtValor.Enabled = true;
            txtValorConvertido.Clear();
            txtValorConvertido.Enabled = true;
            cboDe.SelectedIndex = 0;
            cboDe.Enabled = true;
            cboPara.SelectedIndex = 0;
            cboPara.Enabled = true;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cboDe.SelectedIndex = 0;
            cboPara.SelectedIndex = 0;
        }

        private void cboPara_SelectedIndexChanged(object sender, EventArgs e)
        {
            double valor, valorConvertido = 0;

            if (cboDe.SelectedIndex != 0)
            {
                valor = double.Parse(txtValor.Text);

                if (cboDe.SelectedIndex == 1 && cboPara.SelectedIndex == 1) // dolar para dolar
                {
                    valorConvertido = valor * 1;
                }
                else if (cboDe.SelectedIndex == 1 && cboPara.SelectedIndex == 2) // dolar para euro
                {
                    valorConvertido = valor / 1.11 ;
                }
                else if (cboDe.SelectedIndex == 1 && cboPara.SelectedIndex == 3) // dolar para peso
                {
                    valorConvertido = valor * 945.25;
                }
                else if (cboDe.SelectedIndex == 1 && cboPara.SelectedIndex == 4) // dolar para real
                {
                    valorConvertido = valor * 5.57;
                }
                else if (cboDe.SelectedIndex == 2 && cboPara.SelectedIndex == 1) // euro para dolar
                {
                    valorConvertido = valor * 1.11;
                }
                else if (cboDe.SelectedIndex == 2 && cboPara.SelectedIndex == 2) // euro para euro
                {
                    valorConvertido = valor * 1;
                }
                else if (cboDe.SelectedIndex == 2 && cboPara.SelectedIndex == 3)  // euro para peso
                {
                    valorConvertido = valor * 1050.10;
                }
                else if (cboDe.SelectedIndex == 2 && cboPara.SelectedIndex == 4)  // euro para real
                {
                    valorConvertido = valor * 6.19;
                }
                else if (cboDe.SelectedIndex == 3 && cboPara.SelectedIndex == 1) // peso para dolar
                {
                    valorConvertido = valor / 945.25;
                }
                else if (cboDe.SelectedIndex == 3 && cboPara.SelectedIndex == 2) // peso para euro
                {
                    valorConvertido = valor / 1050.10;
                }
                else if (cboDe.SelectedIndex == 3 && cboPara.SelectedIndex == 3)  // peso para peso
                {
                    valorConvertido = valor * 1;
                }
                else if (cboDe.SelectedIndex == 3 && cboPara.SelectedIndex == 4)  // peso para real
                {
                    valorConvertido = valor / 169.59;
                }
                else if (cboDe.SelectedIndex == 4 && cboPara.SelectedIndex == 1) // real para dolar
                {
                    valorConvertido = valor / 5.57;
                }
                else if (cboDe.SelectedIndex == 4 && cboPara.SelectedIndex == 2) // real para euro
                {
                    valorConvertido = valor / 6.19;
                }
                else if (cboDe.SelectedIndex == 4 && cboPara.SelectedIndex == 3)  // real para peso
                {
                    valorConvertido = valor * 169.59;
                }
                else if (cboDe.SelectedIndex == 4 && cboPara.SelectedIndex == 4)  // real para real
                {
                    valorConvertido = valor * 1;
                }

                txtValorConvertido.Text = valorConvertido.ToString("n2");
                txtValor.Enabled = false;
                txtValorConvertido.Enabled = false;
                cboDe.Enabled = false;
                cboPara.Enabled = false;
            }
            else
            {
                txtValorConvertido.Text = "";
            }
        }
    }
}
