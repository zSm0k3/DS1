﻿namespace ConversorMoedas
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            splitContainer1 = new SplitContainer();
            txtValorConvertido = new TextBox();
            txtValor = new TextBox();
            cboPara = new ComboBox();
            cboDe = new ComboBox();
            lblPara = new Label();
            lblValorConvertido = new Label();
            lblValor = new Label();
            lblDe = new Label();
            lblTitulo = new Label();
            btnSair = new Button();
            btnNovo = new Button();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            SuspendLayout();
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.IsSplitterFixed = true;
            splitContainer1.Location = new Point(0, 0);
            splitContainer1.Name = "splitContainer1";
            splitContainer1.Orientation = Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = Color.RoyalBlue;
            splitContainer1.Panel1.Controls.Add(txtValorConvertido);
            splitContainer1.Panel1.Controls.Add(txtValor);
            splitContainer1.Panel1.Controls.Add(cboPara);
            splitContainer1.Panel1.Controls.Add(cboDe);
            splitContainer1.Panel1.Controls.Add(lblPara);
            splitContainer1.Panel1.Controls.Add(lblValorConvertido);
            splitContainer1.Panel1.Controls.Add(lblValor);
            splitContainer1.Panel1.Controls.Add(lblDe);
            splitContainer1.Panel1.Controls.Add(lblTitulo);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackColor = Color.White;
            splitContainer1.Panel2.Controls.Add(btnSair);
            splitContainer1.Panel2.Controls.Add(btnNovo);
            splitContainer1.Size = new Size(730, 450);
            splitContainer1.SplitterDistance = 347;
            splitContainer1.TabIndex = 0;
            // 
            // txtValorConvertido
            // 
            txtValorConvertido.Font = new Font("Segoe UI", 10F);
            txtValorConvertido.Location = new Point(416, 275);
            txtValorConvertido.Name = "txtValorConvertido";
            txtValorConvertido.Size = new Size(182, 34);
            txtValorConvertido.TabIndex = 8;
            // 
            // txtValor
            // 
            txtValor.Font = new Font("Segoe UI", 10F);
            txtValor.Location = new Point(124, 161);
            txtValor.Name = "txtValor";
            txtValor.Size = new Size(182, 34);
            txtValor.TabIndex = 0;
            // 
            // cboPara
            // 
            cboPara.Font = new Font("Segoe UI", 10F);
            cboPara.FormattingEnabled = true;
            cboPara.Items.AddRange(new object[] { "Selecione", "Dólar(USD)", "Euro(EUR)", "Peso(ARS)", "Real(BRL)" });
            cboPara.Location = new Point(124, 273);
            cboPara.Name = "cboPara";
            cboPara.Size = new Size(182, 36);
            cboPara.TabIndex = 6;
            cboPara.SelectedIndexChanged += cboPara_SelectedIndexChanged;
            // 
            // cboDe
            // 
            cboDe.Font = new Font("Segoe UI", 10F);
            cboDe.FormattingEnabled = true;
            cboDe.Items.AddRange(new object[] { "Selecione", "Dólar(USD)", "Euro(EUR)", "Peso(ARS)", "Real(BRL)" });
            cboDe.Location = new Point(416, 159);
            cboDe.Name = "cboDe";
            cboDe.Size = new Size(182, 36);
            cboDe.TabIndex = 5;
            // 
            // lblPara
            // 
            lblPara.AutoSize = true;
            lblPara.Font = new Font("Segoe UI", 12F);
            lblPara.ForeColor = Color.White;
            lblPara.Location = new Point(124, 222);
            lblPara.Name = "lblPara";
            lblPara.Size = new Size(58, 32);
            lblPara.TabIndex = 4;
            lblPara.Text = "Para";
            // 
            // lblValorConvertido
            // 
            lblValorConvertido.AutoSize = true;
            lblValorConvertido.Font = new Font("Segoe UI", 12F);
            lblValorConvertido.ForeColor = Color.White;
            lblValorConvertido.Location = new Point(416, 222);
            lblValorConvertido.Name = "lblValorConvertido";
            lblValorConvertido.Size = new Size(192, 32);
            lblValorConvertido.TabIndex = 3;
            lblValorConvertido.Text = "Valor Convertido";
            // 
            // lblValor
            // 
            lblValor.AutoSize = true;
            lblValor.Font = new Font("Segoe UI", 12F);
            lblValor.ForeColor = Color.White;
            lblValor.Location = new Point(124, 115);
            lblValor.Name = "lblValor";
            lblValor.Size = new Size(67, 32);
            lblValor.TabIndex = 2;
            lblValor.Text = "Valor";
            // 
            // lblDe
            // 
            lblDe.AutoSize = true;
            lblDe.Font = new Font("Segoe UI", 12F);
            lblDe.ForeColor = Color.White;
            lblDe.Location = new Point(416, 115);
            lblDe.Name = "lblDe";
            lblDe.Size = new Size(44, 32);
            lblDe.TabIndex = 1;
            lblDe.Text = "De";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.White;
            lblTitulo.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            lblTitulo.Location = new Point(142, 27);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(444, 48);
            lblTitulo.TabIndex = 0;
            lblTitulo.Text = ":. Conversor de Moedas .:";
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.Transparent;
            btnSair.BackgroundImage = Properties.Resources.sair;
            btnSair.BackgroundImageLayout = ImageLayout.Zoom;
            btnSair.FlatAppearance.BorderColor = Color.White;
            btnSair.FlatAppearance.BorderSize = 0;
            btnSair.FlatStyle = FlatStyle.Flat;
            btnSair.Location = new Point(152, 18);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(59, 65);
            btnSair.TabIndex = 2;
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // btnNovo
            // 
            btnNovo.BackColor = Color.Transparent;
            btnNovo.BackgroundImage = Properties.Resources.novo;
            btnNovo.BackgroundImageLayout = ImageLayout.Zoom;
            btnNovo.FlatAppearance.BorderColor = Color.White;
            btnNovo.FlatAppearance.BorderSize = 0;
            btnNovo.FlatStyle = FlatStyle.Flat;
            btnNovo.Location = new Point(75, 18);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(59, 65);
            btnNovo.TabIndex = 0;
            btnNovo.UseVisualStyleBackColor = false;
            btnNovo.Click += btnNovo_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(730, 450);
            Controls.Add(splitContainer1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Conversor de Moedas";
            Load += Form1_Load;
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private SplitContainer splitContainer1;
        private TextBox txtValorConvertido;
        private TextBox txtValor;
        private ComboBox cboPara;
        private ComboBox cboDe;
        private Label lblPara;
        private Label lblValorConvertido;
        private Label lblValor;
        private Label lblDe;
        private Label lblTitulo;
        private Button btnNovo;
        private Button btnSair;
    }
}
